from django.contrib import admin
from .models import UploadedZip
# Register your models here.

admin.site.register(UploadedZip)
